VENPALMO
https://github.com/DevinMB/2022-TEK-JAVA-DMB/tree/main/HtmlCssJavascriptSBA
Devin Butts 11/18/2022
VenPalMo front end, the beginings.
Goal of VenPalMo is to provide users with an easy way to send, recieve, and communicate with fellow VenPalMo members.

To run VenPalMo at this time all that is needed is to load the index.html in any web server.

Known Bugs: 